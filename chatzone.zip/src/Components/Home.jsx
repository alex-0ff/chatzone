import React from "react";
import Navbar from "./Navbar";
//import { Link } from "react-router-dom";

function Home() {
    return (
        <div className="theme-main">
            <Navbar />
            <p>appuis sur al pdp</p>
        </div>
    );
}

export default Home;